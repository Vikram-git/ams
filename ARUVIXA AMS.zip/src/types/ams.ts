export type UserRole = 'admin' | 'hr' | 'employee';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  employeeId?: string; // Links to Employee if role is 'employee'
  avatarUrl?: string;
  password?: string; // Used for secure authentication
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  departmentId: string;
  designation: string;
  status: 'active' | 'inactive';
  joinDate: string;
  fingerprintId?: string; // ZKTecho Device ID (e.g. "FP-102")
  salary: number;
  gender: string;
  shiftId: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  headName: string;
  color: string;
}

export interface Shift {
  id: string;
  name: string;
  startTime: string; // e.g., "09:00"
  endTime: string;   // e.g., "17:00"
  lateGracePeriod: number; // in minutes (e.g., 15)
  halfDayMinutes: number; // e.g., 240 minutes
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  date: string; // "YYYY-MM-DD"
  checkIn?: string; // "HH:MM:SS"
  checkOut?: string; // "HH:MM:SS"
  status: 'Present' | 'Absent' | 'On Leave' | 'Late' | 'Half Day';
  source: 'Manual' | 'ARUVIXA AMS Biometric' | 'Web Portal';
  deviceLog?: string; // Details if ARUVIXA AMS (e.g., "Device #1 - Verified")
  isOvertime?: boolean;
  overtimeHours?: number;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  leaveType: 'Annual' | 'Sick' | 'Casual' | 'Maternity' | 'Unpaid';
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  appliedDate: string;
  reviewedBy?: string;
  reviewedDate?: string;
}

export interface Holiday {
  id: string;
  name: string;
  date: string; // "YYYY-MM-DD"
  type: 'National' | 'Religious' | 'Optional';
  description: string;
}

export interface DashboardStats {
  totalEmployees: number;
  presentToday: number;
  lateToday: number;
  onLeaveToday: number;
  absentToday: number;
  averageWorkingHours: number;
  activeLeavesRequests: number;
}
