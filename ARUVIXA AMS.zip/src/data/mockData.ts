import { Employee, Department, Shift, AttendanceRecord, LeaveRequest, Holiday, User } from '../types/ams';

export const mockUsers: User[] = [
  {
    id: 'u-1',
    name: 'Rajesh Kumar',
    email: 'rajesh@aruvixa.com',
    role: 'admin',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'u-2',
    name: 'Priya Sharma',
    email: 'priya@aruvixa.com',
    role: 'hr',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'u-3',
    name: 'Amit Patel',
    email: 'amit@aruvixa.com',
    role: 'employee',
    employeeId: 'emp-101',
    avatarUrl: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'u-4',
    name: 'Neha Verma',
    email: 'neha@aruvixa.com',
    role: 'employee',
    employeeId: 'emp-102',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80'
  }
];

export const mockDepartments: Department[] = [
  { id: 'dept-1', name: 'Software Engineering', code: 'SWE', headName: 'Rajesh Kumar', color: 'indigo' },
  { id: 'dept-2', name: 'Human Resources', code: 'HR', headName: 'Priya Sharma', color: 'pink' },
  { id: 'dept-3', name: 'Finance & Accounts', code: 'FIN', headName: 'Vikram Singh', color: 'emerald' },
  { id: 'dept-4', name: 'Sales & Marketing', code: 'SLM', headName: 'Rohit Verma', color: 'amber' },
  { id: 'dept-5', name: 'Operations & Security', code: 'OPS', headName: 'Suresh Kumar', color: 'teal' }
];

export const mockShifts: Shift[] = [
  { id: 'shift-1', name: 'General Morning Shift', startTime: '09:00', endTime: '17:00', lateGracePeriod: 15, halfDayMinutes: 240 },
  { id: 'shift-2', name: 'Evening Shift', startTime: '16:00', endTime: '00:00', lateGracePeriod: 15, halfDayMinutes: 240 },
  { id: 'shift-3', name: 'Night Shift', startTime: '00:00', endTime: '08:00', lateGracePeriod: 10, halfDayMinutes: 240 }
];

export const mockEmployees: Employee[] = [
  {
    id: 'emp-101',
    name: 'Amit Patel',
    email: 'amit@aruvixa.com',
    phone: '+91 98765 43210',
    departmentId: 'dept-1',
    designation: 'Senior Full Stack Developer',
    status: 'active',
    joinDate: '2022-03-12',
    fingerprintId: 'FP-101',
    salary: 750000,
    gender: 'Male',
    shiftId: 'shift-1'
  },
  {
    id: 'emp-102',
    name: 'Neha Verma',
    email: 'neha@aruvixa.com',
    phone: '+91 98765 43211',
    departmentId: 'dept-1',
    designation: 'UI/UX Designer',
    status: 'active',
    joinDate: '2023-01-15',
    fingerprintId: 'FP-102',
    salary: 550000,
    gender: 'Female',
    shiftId: 'shift-1'
  },
  {
    id: 'emp-103',
    name: 'Rohit Verma',
    email: 'rohit@aruvixa.com',
    phone: '+91 98765 43212',
    departmentId: 'dept-4',
    designation: 'Marketing Director',
    status: 'active',
    joinDate: '2021-06-01',
    fingerprintId: 'FP-103',
    salary: 700000,
    gender: 'Male',
    shiftId: 'shift-1'
  },
  {
    id: 'emp-104',
    name: 'Anjali Singh',
    email: 'anjali@aruvixa.com',
    phone: '+91 98765 43213',
    departmentId: 'dept-2',
    designation: 'HR Executive',
    status: 'active',
    joinDate: '2023-05-10',
    fingerprintId: 'FP-104',
    salary: 450000,
    gender: 'Female',
    shiftId: 'shift-1'
  },
  {
    id: 'emp-105',
    name: 'Vikram Singh',
    email: 'vikram@aruvixa.com',
    phone: '+91 98765 43214',
    departmentId: 'dept-3',
    designation: 'Finance Specialist',
    status: 'active',
    joinDate: '2022-11-20',
    fingerprintId: 'FP-105',
    salary: 600000,
    gender: 'Male',
    shiftId: 'shift-1'
  },
  {
    id: 'emp-106',
    name: 'Arjun Kumar',
    email: 'arjun@aruvixa.com',
    phone: '+91 98765 43215',
    departmentId: 'dept-1',
    designation: 'Junior Developer',
    status: 'active',
    joinDate: '2023-10-01',
    fingerprintId: 'FP-106',
    salary: 350000,
    gender: 'Male',
    shiftId: 'shift-1'
  },
  {
    id: 'emp-107',
    name: 'Priya Gupta',
    email: 'priyagupta@aruvixa.com',
    phone: '+91 98765 43216',
    departmentId: 'dept-5',
    designation: 'Operations Coordinator',
    status: 'inactive',
    joinDate: '2021-02-15',
    fingerprintId: 'FP-107',
    salary: 500000,
    gender: 'Female',
    shiftId: 'shift-1'
  }
];

export const mockHolidays: Holiday[] = [
  { id: 'hol-1', name: 'New Year Day', date: '2026-01-01', type: 'National', description: 'Celebrating the start of the New Year' },
  { id: 'hol-2', name: 'Eid-ul-Fitr Holiday 1', date: '2026-03-20', type: 'Religious', description: 'End of Holy Month of Ramadan' },
  { id: 'hol-3', name: 'Eid-ul-Fitr Holiday 2', date: '2026-03-21', type: 'Religious', description: 'Celebrations continue' },
  { id: 'hol-4', name: 'Labour Day', date: '2026-05-01', type: 'National', description: 'International Workers Day tribute' },
  { id: 'hol-5', name: 'Independence Day', date: '2026-08-19', type: 'National', description: 'Afghan Independence Day Celebration' },
  { id: 'hol-6', name: 'Christmas Day', date: '2026-12-25', type: 'Optional', description: 'Christmas winter holidays' }
];

export const mockLeaves: LeaveRequest[] = [
  {
    id: 'lv-1',
    employeeId: 'emp-101',
    leaveType: 'Annual',
    startDate: '2026-03-05',
    endDate: '2026-03-09',
    days: 4,
    reason: 'Family trip outside the city',
    status: 'Approved',
    appliedDate: '2026-02-28',
    reviewedBy: 'Ali Aqa Atayee',
    reviewedDate: '2026-03-01'
  },
  {
    id: 'lv-2',
    employeeId: 'emp-102',
    leaveType: 'Sick',
    startDate: '2026-02-10',
    endDate: '2026-02-11',
    days: 2,
    reason: 'Suffering from high fever and severe flu',
    status: 'Approved',
    appliedDate: '2026-02-10',
    reviewedBy: 'Vikram Singh',
    reviewedDate: '2026-02-10'
  },
  {
    id: 'lv-3',
    employeeId: 'emp-103',
    leaveType: 'Casual',
    startDate: '2026-04-12',
    endDate: '2026-04-13',
    days: 1.5,
    reason: 'Urgent domestic and official personal work',
    status: 'Pending',
    appliedDate: '2026-04-01'
  },
  {
    id: 'lv-4',
    employeeId: 'emp-105',
    leaveType: 'Annual',
    startDate: '2026-05-15',
    endDate: '2026-05-22',
    days: 7,
    reason: 'Sisters wedding ceremony arrangements',
    status: 'Pending',
    appliedDate: '2026-04-02'
  },
  {
    id: 'lv-5',
    employeeId: 'emp-106',
    leaveType: 'Sick',
    startDate: '2026-03-15',
    endDate: '2026-03-15',
    days: 1,
    reason: 'Dental surgery and appointments',
    status: 'Rejected',
    appliedDate: '2026-03-12',
    reviewedBy: 'Vikram Singh',
    reviewedDate: '2026-03-13'
  }
];

// Generates comprehensive attendance records for past 5 business days
const generatePastAttendance = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  const empIds = ['emp-101', 'emp-102', 'emp-103', 'emp-104', 'emp-105', 'emp-106'];
  const dates = [
    '2026-04-06', // Mon
    '2026-04-07', // Tue
    '2026-04-08', // Wed
    '2026-04-09', // Thu
    '2026-04-10'  // Fri
  ];

  // Map of randomized arrival schedules for each day
  dates.forEach((date, dIdx) => {
    empIds.forEach((empId, eIdx) => {
      let checkIn = '08:50:23';
      let checkOut = '17:05:44';
      let status: AttendanceRecord['status'] = 'Present';
      let source: AttendanceRecord['source'] = 'ARUVIXA AMS Biometric';

      // ARUVIXA AMS Biometric logs are specific
      const deviceLog = `Device #1 - Verified User ${empId.replace('emp-', 'FP-')}`;

      // Introduce some natural variety
      const randomValue = (eIdx + dIdx * 7) % 11;
      
      if (randomValue === 0) {
        // Late arrival
        checkIn = '09:25:12';
        status = 'Late';
      } else if (randomValue === 1 && empId === 'emp-102') {
        // Leave
        status = 'On Leave';
        checkIn = '';
        checkOut = '';
        source = 'Web Portal';
      } else if (randomValue === 2 && empId === 'emp-106') {
        // Absent
        status = 'Absent';
        checkIn = '';
        checkOut = '';
      } else if (randomValue === 3) {
        // Half day
        checkIn = '09:05:00';
        checkOut = '13:00:15';
        status = 'Half Day';
        source = 'Manual';
      } else if (randomValue === 4) {
        // Regular on-time, manual sign-in
        checkIn = '08:42:11';
        checkOut = '17:15:30';
        source = 'Manual';
      } else if (randomValue === 5) {
        // Late but within grace or extreme late
        checkIn = '09:40:00';
        checkOut = '17:00:00';
        status = 'Late';
      } else if (randomValue === 9) {
        // Great early entry with Overtime
        checkIn = '08:30:15';
        checkOut = '19:15:00';
        status = 'Present';
      }

      const rec: AttendanceRecord = {
        id: `att-${date}-${empId}`,
        employeeId: empId,
        date,
        checkIn: checkIn || undefined,
        checkOut: checkOut || undefined,
        status,
        source,
        deviceLog: source === 'ARUVIXA AMS Biometric' ? deviceLog : undefined,
        isOvertime: status === 'Present' && checkOut >= '18:30',
        overtimeHours: status === 'Present' && checkOut >= '18:30' ? 2 : undefined
      };

      records.push(rec);
    });
  });

  // Adding today's live/partial records
  const today = '2026-04-13'; // Current Virtual Date
  
  // Zaryab checked in early
  records.push({
    id: `att-${today}-emp-101`,
    employeeId: 'emp-101',
    date: today,
    checkIn: '08:45:12',
    status: 'Present',
    source: 'ARUVIXA AMS Biometric',
    deviceLog: 'Device #1 - Verified User FP-101'
  });

  // Fatima checked in late today
  records.push({
    id: `att-${today}-emp-102`,
    employeeId: 'emp-102',
    date: today,
    checkIn: '09:35:10',
    status: 'Late',
    source: 'ARUVIXA AMS Biometric',
    deviceLog: 'Device #1 - Verified User FP-102'
  });

  // Mustafa checked in via web portal manual punch
  records.push({
    id: `att-${today}-emp-103`,
    employeeId: 'emp-103',
    date: today,
    checkIn: '08:58:19',
    status: 'Present',
    source: 'Web Portal'
  });

  // Sahar is on approved leave request
  records.push({
    id: `att-${today}-emp-104`,
    employeeId: 'emp-104',
    date: today,
    status: 'On Leave',
    source: 'Web Portal'
  });

  // Zubair Alimi hasn't checked in yet today (marked absent temporarily or pending)
  records.push({
    id: `att-${today}-emp-105`,
    employeeId: 'emp-105',
    date: today,
    status: 'Absent',
    source: 'Manual'
  });

  return records;
};

export const mockAttendance: AttendanceRecord[] = generatePastAttendance();
