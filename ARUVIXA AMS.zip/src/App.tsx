import React, { useState, useEffect } from 'react';
import {
  Users,
  Clock,
  Briefcase,
  FileText,
  UserCheck,
  Search,
  LogOut,
  Sliders,
  CheckCircle,
  XCircle,
  AlertCircle,
  Fingerprint,
  Plus,
  Edit,
  Trash2,
  Building,
  DollarSign,
  TrendingUp,
  CalendarDays,
  Cpu,
  RefreshCw,
  Printer,
  Download,
  Check,
  X
} from 'lucide-react';
import { Employee, Department, Shift, AttendanceRecord, LeaveRequest, Holiday, User } from './types/ams';
import { mockUsers, mockEmployees, mockDepartments, mockShifts, mockHolidays, mockLeaves, mockAttendance } from './data/mockData';

export default function App() {
  // --- LOCAL STORAGE STATE SYNCHRONIZATION ---
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('ams_users');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return mockUsers;
      }
    }
    return mockUsers;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('ams_employees');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return mockEmployees;
      }
    }
    return mockEmployees;
  });

  const [departments, setDepartments] = useState<Department[]>(() => {
    const saved = localStorage.getItem('ams_departments');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return mockDepartments;
      }
    }
    return mockDepartments;
  });

  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('ams_attendance');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return mockAttendance;
      }
    }
    return mockAttendance;
  });

  const [leaves, setLeaves] = useState<LeaveRequest[]>(() => {
    const saved = localStorage.getItem('ams_leaves');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return mockLeaves;
      }
    }
    return mockLeaves;
  });

  const [holidays, setHolidays] = useState<Holiday[]>(() => {
    const saved = localStorage.getItem('ams_holidays');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return mockHolidays;
      }
    }
    return mockHolidays;
  });

  const [shifts] = useState<Shift[]>(mockShifts);

  // Sync back to local storage on changes
  useEffect(() => {
    localStorage.setItem('ams_users', JSON.stringify(users));
  }, [users]);
  useEffect(() => {
    localStorage.setItem('ams_employees', JSON.stringify(employees));
  }, [employees]);
  useEffect(() => {
    localStorage.setItem('ams_departments', JSON.stringify(departments));
  }, [departments]);
  useEffect(() => {
    localStorage.setItem('ams_attendance', JSON.stringify(attendance));
  }, [attendance]);
  useEffect(() => {
    localStorage.setItem('ams_leaves', JSON.stringify(leaves));
  }, [leaves]);
  useEffect(() => {
    localStorage.setItem('ams_holidays', JSON.stringify(holidays));
  }, [holidays]);

  // --- USER AUTHENTICATION & NAVIGATION ---
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('ams_current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'employees' | 'attendance' | 'leaves' | 'departments' | 'holidays' | 'reports' | 'zktecho' | 'settings'>('dashboard');

  // --- TOAST NOTIFICATIONS ---
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // --- MODALS & FORM STATES ---
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [empForm, setEmpForm] = useState({
    id: '',
    name: '',
    email: '',
    phone: '',
    departmentId: 'dept-1',
    designation: '',
    status: 'active' as 'active' | 'inactive',
    joinDate: new Date().toISOString().split('T')[0],
    fingerprintId: '',
    salary: 50000,
    gender: 'Male',
    shiftId: 'shift-1'
  });

  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false);
  const [editingAttendance, setEditingAttendance] = useState<AttendanceRecord | null>(null);
  const [attForm, setAttForm] = useState({
    employeeId: 'emp-101',
    date: new Date().toISOString().split('T')[0],
    checkIn: '09:00',
    checkOut: '17:00',
    status: 'Present' as AttendanceRecord['status'],
    source: 'Manual' as AttendanceRecord['source']
  });

  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);
  const [leaveForm, setLeaveForm] = useState({
    leaveType: 'Annual' as LeaveRequest['leaveType'],
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    reason: ''
  });

  const [isDeptModalOpen, setIsDeptModalOpen] = useState(false);
  const [deptForm, setDeptForm] = useState({
    name: '',
    code: '',
    headName: '',
    color: 'indigo'
  });

  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [holidayForm, setHolidayForm] = useState({
    name: '',
    date: new Date().toISOString().split('T')[0],
    type: 'National' as Holiday['type'],
    description: ''
  });

  // --- FILTER & SEARCH STATES ---
  const [employeeSearch, setEmployeeSearch] = useState('');
  const [employeeDeptFilter, setEmployeeDeptFilter] = useState('');
  const [attendanceDateFilter, setAttendanceDateFilter] = useState(new Date().toISOString().split('T')[0]);
  const [attendanceEmpFilter, setAttendanceEmpFilter] = useState('');

  // --- ZKTECHO SCANNER SIMULATOR STATE ---
  const [scannedEmpId, setScannedEmpId] = useState('emp-101');
  const [scannerAction, setScannerAction] = useState<'checkIn' | 'checkOut'>('checkIn');
  const [scannerTime, setScannerTime] = useState('09:00');
  const [isScanning, setIsScannerActive] = useState(false);
  const [scanResult, setScannerResult] = useState<{ success: boolean; message: string } | null>(null);

  // --- AUTH ACTIONS ---
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    // Admin login
    if (loginEmail === 'rajesh@aruvixa.com' && loginPassword === 'rajesh123') {
      const adminUser: User = {
        id: 'u-1',
        name: 'Rajesh Kumar',
        email: 'rajesh@aruvixa.com',
        role: 'admin',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
      };
      setCurrentUser(adminUser);
      localStorage.setItem('ams_current_user', JSON.stringify(adminUser));
      showToast('Logged in successfully as Administrator!');
      return;
    }

    // Check normal users
    const matchedUser = users.find(u => u.email.toLowerCase() === loginEmail.toLowerCase() && u.password === loginPassword);
    if (matchedUser) {
      setCurrentUser(matchedUser);
      localStorage.setItem('ams_current_user', JSON.stringify(matchedUser));
      showToast(`Logged in as ${matchedUser.name}`);
    } else {
      setLoginError('Invalid email credentials or incorrect password. Please try again.');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('ams_current_user');
    showToast('Logged out successfully.');
  };

  const triggerQuickLogin = (email: string, pass: string) => {
    setLoginEmail(email);
    setLoginPassword(pass);
    setTimeout(() => handleLogin(new Event('submit') as any), 100);
  };

  // --- CRUD ACTIONS ---

  // Employees CRUD
  const handleSaveEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empForm.name || !empForm.email || !empForm.designation) {
      showToast('Please fill out all required fields.', 'error');
      return;
    }

    if (editingEmployee) {
      // Update employee
      const updated = employees.map(emp => emp.id === editingEmployee.id ? { ...emp, ...empForm } : emp);
      setEmployees(updated);
      showToast(`Updated employee ${empForm.name}`);
    } else {
      // Create new employee
      const nextId = `emp-${101 + employees.length}`;
      const newEmp: Employee = {
        ...empForm,
        id: nextId,
        fingerprintId: empForm.fingerprintId || `FP-${101 + employees.length}`
      };
      setEmployees([...employees, newEmp]);
      
      // Auto-create a linked portal user if requested
      const newUser: User = {
        id: `u-${Date.now()}`,
        name: newEmp.name,
        email: newEmp.email.toLowerCase(),
        role: 'employee',
        employeeId: newEmp.id,
        password: newEmp.email.toLowerCase() // Default simple password for demo
      };
      setUsers([...users, newUser]);

      showToast(`Added new employee: ${empForm.name}`);
    }

    setIsEmployeeModalOpen(false);
    setEditingEmployee(null);
  };

  const startEditEmployee = (emp: Employee) => {
    setEditingEmployee(emp);
    setEmpForm({
      ...emp,
      fingerprintId: emp.fingerprintId || ''
    });
    setIsEmployeeModalOpen(true);
  };

  const handleDeleteEmployee = (empId: string) => {
    if (confirm('Are you sure you want to remove this employee? This will delete all attendance records too.')) {
      setEmployees(employees.filter(e => e.id !== empId));
      setAttendance(attendance.filter(a => a.employeeId !== empId));
      showToast('Employee removed successfully.', 'info');
    }
  };

  // Attendance CRUD
  const handleSaveAttendance = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingAttendance) {
      // Update record
      const updated = attendance.map(att => att.id === editingAttendance.id ? {
        ...att,
        checkIn: attForm.checkIn || undefined,
        checkOut: attForm.checkOut || undefined,
        status: attForm.status,
        source: attForm.source
      } : att);
      setAttendance(updated);
      showToast('Attendance record updated successfully.');
    } else {
      // Manual punch
      const existing = attendance.find(a => a.employeeId === attForm.employeeId && a.date === attForm.date);
      if (existing) {
        showToast('This employee already has an attendance log for this date. Edit the existing one.', 'error');
        return;
      }

      const newRecord: AttendanceRecord = {
        id: `att-${Date.now()}`,
        employeeId: attForm.employeeId,
        date: attForm.date,
        checkIn: attForm.checkIn || undefined,
        checkOut: attForm.checkOut || undefined,
        status: attForm.status,
        source: attForm.source
      };
      setAttendance([newRecord, ...attendance]);
      showToast('Manual attendance record logged.');
    }
    setIsAttendanceModalOpen(false);
    setEditingAttendance(null);
  };

  const startEditAttendance = (record: AttendanceRecord) => {
    setEditingAttendance(record);
    setAttForm({
      employeeId: record.employeeId,
      date: record.date,
      checkIn: record.checkIn || '09:00',
      checkOut: record.checkOut || '17:00',
      status: record.status,
      source: record.source
    });
    setIsAttendanceModalOpen(true);
  };

  const handleDeleteAttendance = (id: string) => {
    if (confirm('Are you sure you want to delete this log?')) {
      setAttendance(attendance.filter(a => a.id !== id));
      showToast('Log deleted.', 'info');
    }
  };

  // Leave Requests
  const handleApplyLeave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser?.employeeId) {
      showToast('Only linked employee accounts can apply for leaves.', 'error');
      return;
    }
    if (!leaveForm.reason.trim()) {
      showToast('Please specify a reason.', 'error');
      return;
    }

    const start = new Date(leaveForm.startDate);
    const end = new Date(leaveForm.endDate);
    if (end < start) {
      showToast('End date cannot be earlier than start date.', 'error');
      return;
    }

    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

    const newRequest: LeaveRequest = {
      id: `lv-${Date.now()}`,
      employeeId: currentUser.employeeId,
      leaveType: leaveForm.leaveType,
      startDate: leaveForm.startDate,
      endDate: leaveForm.endDate,
      days: diffDays,
      reason: leaveForm.reason,
      status: 'Pending',
      appliedDate: new Date().toISOString().split('T')[0]
    };

    setLeaves([newRequest, ...leaves]);
    setIsLeaveModalOpen(false);
    setLeaveForm({ ...leaveForm, reason: '' });
    showToast('Your leave request has been submitted for approval.', 'success');
  };

  const handleReviewLeave = (leaveId: string, status: 'Approved' | 'Rejected') => {
    const updated = leaves.map(l => {
      if (l.id === leaveId) {
        // If approved, retroactively insert/update AttendanceRecord for those dates!
        if (status === 'Approved') {
          // Add attendance records as 'On Leave'
          const start = new Date(l.startDate);
          const end = new Date(l.endDate);
          const tempDate = new Date(start);
          const newRecords: AttendanceRecord[] = [];

          while (tempDate <= end) {
            const dateStr = tempDate.toISOString().split('T')[0];
            // Only insert if no record exists or override
            const exists = attendance.some(a => a.employeeId === l.employeeId && a.date === dateStr);
            if (!exists) {
              newRecords.push({
                id: `att-leave-${Date.now()}-${dateStr}-${l.employeeId}`,
                employeeId: l.employeeId,
                date: dateStr,
                status: 'On Leave',
                source: 'Web Portal'
              });
            }
            tempDate.setDate(tempDate.getDate() + 1);
          }
          if (newRecords.length > 0) {
            setAttendance(prev => [...newRecords, ...prev]);
          }
        }

        return {
          ...l,
          status,
          reviewedBy: currentUser?.name || 'HR Manager',
          reviewedDate: new Date().toISOString().split('T')[0]
        };
      }
      return l;
    });

    setLeaves(updated);
    showToast(`Leave request ${status.toLowerCase()} successfully.`);
  };

  // Departments CRUD
  const handleSaveDepartment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deptForm.name || !deptForm.code) return;

    const newDept: Department = {
      id: `dept-${Date.now()}`,
      name: deptForm.name,
      code: deptForm.code.toUpperCase(),
      headName: deptForm.headName || 'Vacant',
      color: deptForm.color
    };

    setDepartments([...departments, newDept]);
    setIsDeptModalOpen(false);
    setDeptForm({ name: '', code: '', headName: '', color: 'indigo' });
    showToast(`Department "${newDept.name}" created.`);
  };

  // Holidays CRUD
  const handleSaveHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!holidayForm.name || !holidayForm.date) return;

    const newHoliday: Holiday = {
      id: `hol-${Date.now()}`,
      ...holidayForm
    };

    setHolidays([...holidays, newHoliday]);
    setIsHolidayModalOpen(false);
    setHolidayForm({ name: '', date: new Date().toISOString().split('T')[0], type: 'National', description: '' });
    showToast(`New holiday added: ${newHoliday.name}`);
  };

  // --- ZKTECHO FINGERPRINT DEVICE SCANNER SIMULATION ---
  const simulateFingerprintScan = () => {
    const selectedEmp = employees.find(e => e.id === scannedEmpId);
    if (!selectedEmp) {
      showToast('Select an employee for scanning', 'error');
      return;
    }

    setIsScannerActive(true);
    setScannerResult(null);

    // Simulate biometric scanning latency
    setTimeout(() => {
      const todayStr = new Date().toISOString().split('T')[0];
      const existingToday = attendance.find(a => a.employeeId === selectedEmp.id && a.date === todayStr);

      if (scannerAction === 'checkIn') {
        if (existingToday && existingToday.checkIn) {
          setScannerResult({
            success: false,
            message: `FAILED: FP Sensor indicates user ${selectedEmp.fingerprintId} already checked in at ${existingToday.checkIn}.`
          });
          setIsScannerActive(false);
          return;
        }

        // Calculate if late
        const targetShift = shifts.find(s => s.id === selectedEmp.shiftId) || shifts[0];
        const [shiftH, shiftM] = targetShift.startTime.split(':').map(Number);
        const [scanH, scanM] = scannerTime.split(':').map(Number);
        const totalShiftMin = shiftH * 60 + shiftM;
        const totalScanMin = scanH * 60 + scanM;
        const minutesDiff = totalScanMin - totalShiftMin;

        let finalStatus: AttendanceRecord['status'] = 'Present';
        if (minutesDiff > targetShift.lateGracePeriod) {
          finalStatus = 'Late';
        }

        const newRecord: AttendanceRecord = {
          id: `att-zk-${Date.now()}`,
          employeeId: selectedEmp.id,
          date: todayStr,
          checkIn: `${scannerTime}:00`,
          status: finalStatus,
          source: 'ARUVIXA AMS Biometric',
          deviceLog: `Biometric ARUVIXA AMS - Auth ID ${selectedEmp.fingerprintId} OK`
        };

        setAttendance([newRecord, ...attendance]);
        setScannerResult({
          success: true,
          message: `SUCCESS: ZKTecho scan verified! ${selectedEmp.name} checked in at ${scannerTime}. Status: ${finalStatus}`
        });
      } else {
        // Check out
        if (!existingToday) {
          setScannerResult({
            success: false,
            message: `REJECTED: No morning Check-In record found for ${selectedEmp.name} today.`
          });
          setIsScannerActive(false);
          return;
        }

        const updated = attendance.map(a => {
          if (a.employeeId === selectedEmp.id && a.date === todayStr) {
            return {
              ...a,
              checkOut: `${scannerTime}:00`,
              isOvertime: scannerTime >= '18:30',
              overtimeHours: scannerTime >= '18:30' ? 2 : undefined
            };
          }
          return a;
        });

        setAttendance(updated);
        setScannerResult({
          success: true,
          message: `SUCCESS: ZKTecho Check-Out processed for ${selectedEmp.name} at ${scannerTime}. Have a good evening!`
        });
      }
      setIsScannerActive(false);
    }, 1800);
  };

  // --- STATS COMPUTATIONS ---
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayAttendance = attendance.filter(a => a.date === todayDateStr);
  
  const presentCount = todayAttendance.filter(a => a.status === 'Present' || a.status === 'Late' || a.status === 'Half Day').length;
  const lateCount = todayAttendance.filter(a => a.status === 'Late').length;
  const leaveCount = todayAttendance.filter(a => a.status === 'On Leave').length;
  const absentCount = employees.filter(e => e.status === 'active').length - presentCount - leaveCount;
  const activePendingLeaves = leaves.filter(l => l.status === 'Pending').length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-slate-800">
      
      {/* Toast message notification */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-4 rounded-xl shadow-2xl transition-all duration-300 transform translate-y-0 text-white ${
          toast.type === 'success' ? 'bg-emerald-600' : toast.type === 'error' ? 'bg-rose-600' : 'bg-indigo-600'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="h-5 w-5" /> : toast.type === 'error' ? <XCircle className="h-5 w-5" /> : <AlertCircle className="h-5 w-5" />}
          <span className="font-medium text-sm">{toast.message}</span>
        </div>
      )}

      {/* --- RENDER LOGIN VIEW --- */}
      {!currentUser ? (
        <div className="flex-1 flex flex-col md:flex-row min-h-screen">
          
          {/* Brand Panel */}
          <div className="md:w-1/2 bg-gradient-to-br from-indigo-700 via-indigo-800 to-slate-900 flex flex-col justify-between p-10 md:p-16 text-white">
            <div className="flex items-center gap-3">
              <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-md">
                <Fingerprint className="h-8 w-8 text-indigo-300" />
              </div>
              <span className="text-2xl font-bold tracking-wider">ARUVIXA-AMS</span>
            </div>

            <div className="my-12">
              <h1 className="text-4xl md:text-5xl font-extrabold leading-tight mb-4 text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-100 to-indigo-200">
                Attendance Management System
              </h1>
              <p className="text-indigo-200 text-lg max-w-md leading-relaxed">
                Biometric ARUVIXA AMS integrations, shifts, real-time tracking, leave policies and automated payroll metrics in a single digital command centre.
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs text-indigo-300 border-t border-white/10 pt-6">
              <span>🚀 ARUVIXA AMS v3.4.1</span>
              <span>•</span>
              <span>⚡ Powered by React & ARUVIXA Biometrics</span>
            </div>
          </div>

          {/* Login Credentials Form */}
          <div className="md:w-1/2 bg-slate-50 flex items-center justify-center p-8 md:p-16">
            <div className="w-full max-w-md bg-white rounded-3xl p-8 md:p-10 shadow-xl shadow-slate-100 border border-slate-100">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Sign In to Dashboard</h2>
              <p className="text-sm text-slate-500 mb-8">Access your HR portal or Employee logbooks.</p>

              {loginError && (
                <div className="bg-rose-50 text-rose-700 border border-rose-100 p-3.5 rounded-xl text-sm mb-6 flex items-start gap-2.5">
                  <AlertCircle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">Email Address</label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none placeholder:text-slate-400"
                    placeholder="Enter official email"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">Secure Password</label>
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none placeholder:text-slate-400"
                    placeholder="••••••••"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-indigo-600 text-white rounded-xl font-semibold text-sm shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 hover:shadow-indigo-600/30 transition-all"
                >
                  Authenticate Session
                </button>
              </form>

              {/* Demo Quick login links */}
              <div className="mt-8 pt-8 border-t border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-4 text-center">
                  Quick Access Profiles
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <button
                    onClick={() => triggerQuickLogin('rajesh@aruvixa.com', 'rajesh123')}
                    className="flex flex-col items-start p-3 rounded-xl border border-slate-100 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-200 transition-all text-left"
                  >
                    <span className="font-semibold text-slate-800">👨‍💼 Admin</span>
                    <span className="text-slate-500">rajesh@aruvixa.com</span>
                  </button>
                  <button
                    onClick={() => triggerQuickLogin('priya@aruvixa.com', 'priya@aruvixa.com')}
                    className="flex flex-col items-start p-3 rounded-xl border border-slate-100 bg-slate-50 hover:bg-pink-50 hover:border-pink-200 transition-all text-left"
                  >
                    <span className="font-semibold text-slate-800">👩‍💼 HR Manager</span>
                    <span className="text-slate-500">priya@aruvixa.com</span>
                  </button>
                  <button
                    onClick={() => triggerQuickLogin('amit@aruvixa.com', 'amit@aruvixa.com')}
                    className="flex flex-col items-start p-3 rounded-xl border border-slate-100 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-200 transition-all text-left"
                  >
                    <span className="font-semibold text-slate-800">💻 Amit (Engineer)</span>
                    <span className="text-slate-500">amit@aruvixa.com</span>
                  </button>
                  <button
                    onClick={() => triggerQuickLogin('neha@aruvixa.com', 'neha@aruvixa.com')}
                    className="flex flex-col items-start p-3 rounded-xl border border-slate-100 bg-slate-50 hover:bg-amber-50 hover:border-amber-200 transition-all text-left"
                  >
                    <span className="font-semibold text-slate-800">🎨 Neha (Designer)</span>
                    <span className="text-slate-500">neha@aruvixa.com</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* --- RENDER PORTAL SYSTEM VIEW --- */
        <div className="flex-1 flex overflow-hidden">
          
          {/* Left Vertical Sidebar */}
          <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col justify-between shrink-0 shadow-xl">
            <div>
              {/* Sidebar Brand Header */}
              <div className="p-6 bg-slate-950 flex items-center gap-3 border-b border-slate-800">
                <div className="bg-indigo-600 p-1.5 rounded-lg text-white">
                  <Fingerprint className="h-6 w-6" />
                </div>
                <div>
                  <span className="text-lg font-bold text-white tracking-wide block">AMS System</span>
                  <span className="text-xs text-indigo-400 font-medium">Core Biometrics DB</span>
                </div>
              </div>

              {/* User Bio Status */}
              <div className="p-5 border-b border-slate-800 bg-slate-900/50 flex items-center gap-3">
                <img
                  src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=80&q=80'}
                  alt="user avatar"
                  className="w-10 h-10 rounded-full border-2 border-indigo-500 object-cover"
                />
                <div className="overflow-hidden">
                  <span className="font-bold text-white block text-sm truncate">{currentUser.name}</span>
                  <span className="text-xs text-slate-400 capitalize block">{currentUser.role} Account</span>
                </div>
              </div>

              {/* Sidebar Navigation items */}
              <nav className="p-4 space-y-1">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <Sliders className="h-4 w-4" />
                  <span>Command Center</span>
                </button>

                {currentUser.role !== 'employee' && (
                  <button
                    onClick={() => setActiveTab('employees')}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                      activeTab === 'employees' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Users className="h-4 w-4" />
                    <span>Employees List</span>
                  </button>
                )}

                <button
                  onClick={() => setActiveTab('attendance')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === 'attendance' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <Clock className="h-4 w-4" />
                  <span>Attendance Log</span>
                </button>

                <button
                  onClick={() => setActiveTab('leaves')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === 'leaves' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <Briefcase className="h-4 w-4" />
                  <span>Leaves & Requests</span>
                  {activePendingLeaves > 0 && currentUser.role !== 'employee' && (
                    <span className="ml-auto bg-amber-500 text-slate-900 text-xs font-bold px-2 py-0.5 rounded-full">
                      {activePendingLeaves}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('departments')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === 'departments' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <Building className="h-4 w-4" />
                  <span>Departments</span>
                </button>

                <button
                  onClick={() => setActiveTab('holidays')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === 'holidays' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <CalendarDays className="h-4 w-4" />
                  <span>Holidays Calendar</span>
                </button>

                <button
                  onClick={() => setActiveTab('reports')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === 'reports' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <FileText className="h-4 w-4" />
                  <span>Reports & Export</span>
                </button>

                {/* Biometric machine scanner simulator tab */}
                <button
                  onClick={() => setActiveTab('zktecho')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all border border-indigo-500/20 bg-indigo-950/20 ${
                    activeTab === 'zktecho' ? 'bg-indigo-600 text-white' : 'hover:bg-indigo-950/50 text-indigo-400'
                  }`}
                >
                  <Cpu className="h-4 w-4" />
                  <span>ARUVIXA AMS Scanner</span>
                </button>
              </nav>
            </div>

            {/* Logout Footer Section */}
            <div className="p-4 border-t border-slate-800">
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 text-rose-400 hover:text-white hover:bg-rose-950/40 rounded-xl text-sm font-semibold transition-all border border-transparent hover:border-rose-900/30"
              >
                <LogOut className="h-4 w-4" />
                <span>Disconnect Portal</span>
              </button>
            </div>
          </aside>

          {/* Right Main Panel Body */}
          <main className="flex-1 overflow-y-auto flex flex-col">
            
            {/* Top Bar Header */}
            <header className="bg-white border-b border-slate-150 h-16 shrink-0 flex items-center justify-between px-8 sticky top-0 z-10">
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-semibold text-xs uppercase tracking-widest">Portal Navigation</span>
                <span className="text-slate-300 text-sm">/</span>
                <span className="text-slate-800 font-bold text-sm capitalize">{activeTab} View</span>
              </div>

              <div className="flex items-center gap-4">
                <div className="bg-slate-100 text-slate-600 text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5">
                  <span className="h-2 w-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  ARUVIXA AMS Biometric SDK Online
                </div>

                <div className="text-right text-xs">
                  <span className="text-slate-400 block font-medium">Virtual Work Date</span>
                  <span className="text-slate-800 font-bold">Monday, April 13, 2026</span>
                </div>
              </div>
            </header>

            {/* View Render Router Switch */}
            <div className="p-8 flex-1">

              {/* TAB 1: DASHBOARD COMMAND CENTER */}
              {activeTab === 'dashboard' && (
                <div className="space-y-8">
                  
                  {/* Stats Ribbon */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    
                    {/* Stat CARD 1 */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center justify-between">
                      <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Staff Force</span>
                        <h3 className="text-3xl font-bold text-slate-800">{employees.filter(e => e.status === 'active').length}</h3>
                        <p className="text-xs text-emerald-600 font-medium">Active biometric user IDs</p>
                      </div>
                      <div className="bg-indigo-50 text-indigo-600 p-4 rounded-xl">
                        <Users className="h-6 w-6" />
                      </div>
                    </div>

                    {/* Stat CARD 2 */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center justify-between">
                      <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Present Today</span>
                        <h3 className="text-3xl font-bold text-emerald-600">{presentCount}</h3>
                        <p className="text-xs text-slate-500">Includes {lateCount} late arrivals</p>
                      </div>
                      <div className="bg-emerald-50 text-emerald-600 p-4 rounded-xl">
                        <UserCheck className="h-6 w-6" />
                      </div>
                    </div>

                    {/* Stat CARD 3 */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center justify-between">
                      <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">On Authorized Leave</span>
                        <h3 className="text-3xl font-bold text-amber-600">{leaveCount}</h3>
                        <p className="text-xs text-slate-500">Paid & Medical requests</p>
                      </div>
                      <div className="bg-amber-50 text-amber-600 p-4 rounded-xl">
                        <Briefcase className="h-6 w-6" />
                      </div>
                    </div>

                    {/* Stat CARD 4 */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center justify-between">
                      <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Absent / Pending</span>
                        <h3 className="text-3xl font-bold text-rose-600">{absentCount > 0 ? absentCount : 0}</h3>
                        <p className="text-xs text-slate-500">No fingerprint recorded today</p>
                      </div>
                      <div className="bg-rose-50 text-rose-600 p-4 rounded-xl">
                        <AlertCircle className="h-6 w-6" />
                      </div>
                    </div>
                  </div>

                  {/* ARUVIXA AMS Device Quick Banner */}
                  <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
                    <div className="flex items-center gap-4">
                      <div className="bg-indigo-500/20 p-3 rounded-2xl border border-indigo-500/30 text-indigo-400 animate-pulse">
                        <Fingerprint className="h-8 w-8" />
                      </div>
                      <div>
                        <h4 className="text-lg font-bold">ARUVIXA AMS Biometric Terminal Simulator</h4>
                        <p className="text-xs text-slate-400 max-w-md">
                          Replicate physical hardware machine punches. Instantly tests shift late-penalties, overtime limits and live presence calculations.
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setActiveTab('zktecho')}
                      className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
                    >
                      Open ARUVIXA AMS Scanner Interface
                    </button>
                  </div>

                  {/* Two-Column Analytics Layout */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* Left: Live Today Logs Feed */}
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 lg:col-span-2">
                      <div className="flex items-center justify-between mb-6">
                        <div>
                          <h4 className="font-bold text-slate-900 text-lg">Today's Realtime Presence Ticker</h4>
                          <p className="text-xs text-slate-500">Live feeds matching ZKTecho terminal scanner packets</p>
                        </div>
                        <button
                          onClick={() => setAttendance([...attendance])}
                          className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                          title="Refresh Streams"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="space-y-4">
                        {todayAttendance.length > 0 ? (
                          todayAttendance.map((record) => {
                            const emp = employees.find(e => e.id === record.employeeId);
                            const dept = departments.find(d => d?.id === emp?.departmentId);
                            return (
                              <div
                                key={record.id}
                                className="flex items-center justify-between p-4 bg-slate-50 hover:bg-slate-100 rounded-2xl transition-all border border-slate-100"
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`h-2.5 w-2.5 rounded-full ${
                                    record.status === 'Present' ? 'bg-emerald-500' :
                                    record.status === 'Late' ? 'bg-amber-500' :
                                    record.status === 'On Leave' ? 'bg-indigo-500' : 'bg-rose-500'
                                  }`} />
                                  <div>
                                    <span className="font-semibold text-slate-800 text-sm block">{emp?.name || 'Unknown Staff'}</span>
                                    <span className="text-xs text-slate-500">{emp?.designation} • <span className="font-bold text-indigo-600">{dept?.name}</span></span>
                                  </div>
                                </div>

                                <div className="text-right text-xs">
                                  {record.checkIn ? (
                                    <div className="space-y-1">
                                      <span className="font-bold text-slate-800 block text-sm">Checked In {record.checkIn}</span>
                                      <span className="text-slate-400 block text-[10px] tracking-wide uppercase font-semibold">
                                        Source: {record.source}
                                      </span>
                                    </div>
                                  ) : (
                                    <span className="text-slate-400 italic">No entry logs logged</span>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <div className="text-center py-12 text-slate-400">
                            <Clock className="h-10 w-10 mx-auto opacity-30 mb-3" />
                            <p className="text-sm">No biometric activities recorded today yet.</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right: Quick Departments Overview */}
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                      <div className="flex items-center justify-between mb-6">
                        <h4 className="font-bold text-slate-900 text-lg">Workforce Spread</h4>
                        <Building className="h-5 w-5 text-slate-400" />
                      </div>

                      <div className="space-y-5">
                        {departments.map((dept) => {
                          const count = employees.filter(e => e.departmentId === dept.id && e.status === 'active').length;
                          const totalActive = employees.filter(e => e.status === 'active').length || 1;
                          const percent = Math.round((count / totalActive) * 100);

                          return (
                            <div key={dept.id} className="space-y-2">
                              <div className="flex items-center justify-between text-xs font-semibold">
                                <span className="text-slate-700">{dept.name}</span>
                                <span className="text-slate-400">{count} staff ({percent}%)</span>
                              </div>
                              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                                <div
                                  className="h-full rounded-full transition-all"
                                  style={{
                                    width: `${percent}%`,
                                    backgroundColor: dept.color === 'indigo' ? '#4f46e5' :
                                                     dept.color === 'pink' ? '#db2777' :
                                                     dept.color === 'emerald' ? '#059669' :
                                                     dept.color === 'amber' ? '#d97706' : '#0d9488'
                                  }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: EMPLOYEES CRUD DIRECTORY */}
              {activeTab === 'employees' && (
                <div className="space-y-6">
                  
                  {/* Directory Header Control Panel */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">Employees Directory</h2>
                      <p className="text-xs text-slate-500">Admin/HR controls for enrollment, biometric fingerprint mapping and salary parameters</p>
                    </div>
                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => {
                          setEditingEmployee(null);
                          setEmpForm({
                            id: '',
                            name: '',
                            email: '',
                            phone: '',
                            departmentId: 'dept-1',
                            designation: '',
                            status: 'active',
                            joinDate: new Date().toISOString().split('T')[0],
                            fingerprintId: `FP-${101 + employees.length}`,
                            salary: 60000,
                            gender: 'Male',
                            shiftId: 'shift-1'
                          });
                          setIsEmployeeModalOpen(true);
                        }}
                        className="flex items-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-indigo-600/15"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Enroll New Staff</span>
                      </button>
                    )}
                  </div>

                  {/* Filters Ribbon */}
                  <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex flex-col md:flex-row items-center gap-4">
                    <div className="relative w-full md:w-80">
                      <Search className="h-4 w-4 text-slate-400 absolute left-4.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Search by name, email or fingerprint ID..."
                        value={employeeSearch}
                        onChange={(e) => setEmployeeSearch(e.target.value)}
                        className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none placeholder:text-slate-400"
                      />
                    </div>

                    <div className="w-full md:w-60">
                      <select
                        value={employeeDeptFilter}
                        onChange={(e) => setEmployeeDeptFilter(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none text-slate-600"
                      >
                        <option value="">All Departments</option>
                        {departments.map(d => (
                          <option key={d.id} value={d.id}>{d.name}</option>
                        ))}
                      </select>
                    </div>

                    {(employeeSearch || employeeDeptFilter) && (
                      <button
                        onClick={() => { setEmployeeSearch(''); setEmployeeDeptFilter(''); }}
                        className="text-xs text-indigo-600 font-bold hover:underline py-2"
                      >
                        Reset Filters
                      </button>
                    )}
                  </div>

                  {/* Employees Table Grid */}
                  <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse text-left text-sm text-slate-600">
                        <thead className="bg-slate-50 text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100">
                          <tr>
                            <th className="py-4.5 px-6">ID & Employee details</th>
                            <th className="py-4.5 px-6">Department</th>
                            <th className="py-4.5 px-6">Biometric Finger ID</th>
                            <th className="py-4.5 px-6">Compensation</th>
                            <th className="py-4.5 px-6">Status</th>
                            {currentUser.role === 'admin' && <th className="py-4.5 px-6 text-right">Actions</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {employees
                            .filter(emp => {
                              const matchesSearch = emp.name.toLowerCase().includes(employeeSearch.toLowerCase()) ||
                                emp.email.toLowerCase().includes(employeeSearch.toLowerCase()) ||
                                (emp.fingerprintId && emp.fingerprintId.toLowerCase().includes(employeeSearch.toLowerCase()));
                              const matchesDept = employeeDeptFilter ? emp.departmentId === employeeDeptFilter : true;
                              return matchesSearch && matchesDept;
                            })
                            .map((emp) => {
                              const dept = departments.find(d => d.id === emp.departmentId);
                              return (
                                <tr key={emp.id} className="hover:bg-slate-50/70 transition-all">
                                  <td className="py-4.5 px-6">
                                    <div className="flex items-center gap-3">
                                      <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-700">
                                        {emp.name.charAt(0)}
                                      </div>
                                      <div>
                                        <span className="font-bold text-slate-900 block text-sm leading-tight">{emp.name}</span>
                                        <span className="text-xs text-slate-400 block mt-0.5">{emp.designation} • Join: {emp.joinDate}</span>
                                        <span className="text-xs text-slate-400 block mt-0.5">{emp.email} • {emp.phone}</span>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-4.5 px-6 font-medium text-slate-900">
                                    <span className="inline-flex px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700">
                                      {dept?.name || 'Unassigned'}
                                    </span>
                                  </td>
                                  <td className="py-4.5 px-6">
                                    <span className="font-mono text-xs font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded border border-slate-200">
                                      {emp.fingerprintId || 'FP-NOT-MAPPED'}
                                    </span>
                                  </td>
                                  <td className="py-4.5 px-6 font-semibold text-slate-800">
                                    ₹{emp.salary.toLocaleString('en-IN')}/mo
                                  </td>
                                  <td className="py-4.5 px-6">
                                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                                      emp.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                                    }`}>
                                      <span className={`h-1.5 w-1.5 rounded-full ${emp.status === 'active' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                                      {emp.status === 'active' ? 'Active' : 'Suspended'}
                                    </span>
                                  </td>
                                  {currentUser.role === 'admin' && (
                                    <td className="py-4.5 px-6 text-right space-x-2">
                                      <button
                                        onClick={() => startEditEmployee(emp)}
                                        className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                        title="Edit Information"
                                      >
                                        <Edit className="h-4 w-4" />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteEmployee(emp.id)}
                                        className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                        title="De-enroll Staff"
                                      >
                                        <Trash2 className="h-4 w-4" />
                                      </button>
                                    </td>
                                  )}
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: ATTENDANCE LOG */}
              {activeTab === 'attendance' && (
                <div className="space-y-6">
                  
                  {/* Page header controls */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">Attendance Database Logs</h2>
                      <p className="text-xs text-slate-500">Comprehensive overview of manual sign-ins and biometric events</p>
                    </div>
                    {currentUser.role !== 'employee' && (
                      <button
                        onClick={() => {
                          setEditingAttendance(null);
                          setAttForm({
                            employeeId: 'emp-101',
                            date: new Date().toISOString().split('T')[0],
                            checkIn: '09:00',
                            checkOut: '17:00',
                            status: 'Present',
                            source: 'Manual'
                          });
                          setIsAttendanceModalOpen(true);
                        }}
                        className="flex items-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-indigo-600/15"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Log Manual Sign-In</span>
                      </button>
                    )}
                  </div>

                  {/* Filter Toolbar */}
                  <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex flex-col md:flex-row items-center gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Log Date Filter</label>
                      <input
                        type="date"
                        value={attendanceDateFilter}
                        onChange={(e) => setAttendanceDateFilter(e.target.value)}
                        className="px-4 py-2 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none text-slate-600"
                      />
                    </div>

                    <div className="w-full md:w-60">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Employee Filter</label>
                      <select
                        value={attendanceEmpFilter}
                        onChange={(e) => setAttendanceEmpFilter(e.target.value)}
                        className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none text-slate-600"
                      >
                        <option value="">All Employees</option>
                        {employees.map(e => (
                          <option key={e.id} value={e.id}>{e.name}</option>
                        ))}
                      </select>
                    </div>

                    {(attendanceDateFilter || attendanceEmpFilter) && (
                      <button
                        onClick={() => { setAttendanceDateFilter(''); setAttendanceEmpFilter(''); }}
                        className="text-xs text-indigo-600 font-bold hover:underline md:self-end py-2"
                      >
                        Reset Filter Options
                      </button>
                    )}
                  </div>

                  {/* Records Table */}
                  <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse text-left text-sm text-slate-600">
                        <thead className="bg-slate-50 text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100">
                          <tr>
                            <th className="py-4.5 px-6">Employee Details</th>
                            <th className="py-4.5 px-6">Check-In Date</th>
                            <th className="py-4.5 px-6">Time-In Log</th>
                            <th className="py-4.5 px-6">Time-Out Log</th>
                            <th className="py-4.5 px-6">Source Method</th>
                            <th className="py-4.5 px-6">Calculated Status</th>
                            {currentUser.role !== 'employee' && <th className="py-4.5 px-6 text-right">Actions</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {attendance
                            .filter(record => {
                              const matchesDate = attendanceDateFilter ? record.date === attendanceDateFilter : true;
                              const matchesEmp = attendanceEmpFilter ? record.employeeId === attendanceEmpFilter : true;
                              
                              // If employee role, ONLY show their own records
                              if (currentUser.role === 'employee') {
                                return record.employeeId === currentUser.employeeId && matchesDate;
                              }

                              return matchesDate && matchesEmp;
                            })
                            .map((record) => {
                              const emp = employees.find(e => e.id === record.employeeId);
                              return (
                                <tr key={record.id} className="hover:bg-slate-50/70 transition-all">
                                  <td className="py-4.5 px-6 font-bold text-slate-900">
                                    {emp?.name || 'De-enrolled Staff Member'}
                                    <span className="block font-medium text-xs text-slate-400">{emp?.designation}</span>
                                  </td>
                                  <td className="py-4.5 px-6 font-semibold text-slate-600">{record.date}</td>
                                  <td className="py-4.5 px-6 font-mono text-sm">{record.checkIn || '--:--:--'}</td>
                                  <td className="py-4.5 px-6 font-mono text-sm">{record.checkOut || '--:--:--'}</td>
                                   <td className="py-4.5 px-6 text-xs font-semibold">
                                    <span className={`inline-flex px-2 py-0.5 rounded ${
                                      record.source === 'ARUVIXA AMS Biometric' ? 'bg-indigo-50 text-indigo-700' :
                                      record.source === 'Web Portal' ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-slate-700'
                                    }`}>
                                      {record.source}
                                    </span>
                                  </td>
                                  <td className="py-4.5 px-6">
                                    <span className={`inline-flex px-2.5 py-1 rounded-lg text-xs font-bold ${
                                      record.status === 'Present' ? 'bg-emerald-50 text-emerald-700' :
                                      record.status === 'Late' ? 'bg-amber-50 text-amber-700' :
                                      record.status === 'On Leave' ? 'bg-indigo-50 text-indigo-700' : 'bg-rose-50 text-rose-700'
                                    }`}>
                                      {record.status}
                                    </span>
                                  </td>
                                  {currentUser.role !== 'employee' && (
                                    <td className="py-4.5 px-6 text-right space-x-2">
                                      <button
                                        onClick={() => startEditAttendance(record)}
                                        className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                        title="Adjust Log"
                                      >
                                        <Edit className="h-4 w-4" />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteAttendance(record.id)}
                                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                        title="Wipe record"
                                      >
                                        <Trash2 className="h-4 w-4" />
                                      </button>
                                    </td>
                                  )}
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: LEAVE REQUESTS */}
              {activeTab === 'leaves' && (
                <div className="space-y-6">
                  
                  {/* Header Options */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">Leave Applications Panel</h2>
                      <p className="text-xs text-slate-500">Apply for leave, verify sick certificates and approve annual vacations</p>
                    </div>
                    {currentUser.role === 'employee' && (
                      <button
                        onClick={() => {
                          setLeaveForm({
                            leaveType: 'Annual',
                            startDate: new Date().toISOString().split('T')[0],
                            endDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
                            reason: ''
                          });
                          setIsLeaveModalOpen(true);
                        }}
                        className="flex items-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-indigo-600/15"
                      >
                        <Plus className="h-4 w-4" />
                        <span>File Leave Application</span>
                      </button>
                    )}
                  </div>

                  {/* Requests Grid */}
                  <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-6 border-b border-slate-100">
                      <h3 className="font-bold text-slate-900">Active Leave Logs</h3>
                    </div>
                    
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse text-left text-sm text-slate-600">
                        <thead className="bg-slate-50 text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100">
                          <tr>
                            <th className="py-4.5 px-6">Applicant Employee</th>
                            <th className="py-4.5 px-6">Leave Classification</th>
                            <th className="py-4.5 px-6">From Date</th>
                            <th className="py-4.5 px-6">To Date</th>
                            <th className="py-4.5 px-6">Total Days</th>
                            <th className="py-4.5 px-6">Applicant Reason</th>
                            <th className="py-4.5 px-6">Resolution Status</th>
                            {currentUser.role !== 'employee' && <th className="py-4.5 px-6 text-right">Actions</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {leaves
                            .filter(leave => {
                              if (currentUser.role === 'employee') {
                                return leave.employeeId === currentUser.employeeId;
                              }
                              return true;
                            })
                            .map((leave) => {
                              const emp = employees.find(e => e.id === leave.employeeId);
                              return (
                                <tr key={leave.id} className="hover:bg-slate-50/70 transition-all">
                                  <td className="py-4.5 px-6 font-bold text-slate-900">
                                    {emp?.name || 'Staff Member'}
                                    <span className="block font-medium text-xs text-slate-400">{emp?.designation}</span>
                                  </td>
                                  <td className="py-4.5 px-6">
                                    <span className="inline-flex px-2 py-0.5 rounded text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100">
                                      {leave.leaveType}
                                    </span>
                                  </td>
                                  <td className="py-4.5 px-6 font-semibold text-slate-600">{leave.startDate}</td>
                                  <td className="py-4.5 px-6 font-semibold text-slate-600">{leave.endDate}</td>
                                  <td className="py-4.5 px-6 font-bold text-slate-700">{leave.days} Days</td>
                                  <td className="py-4.5 px-6 italic text-slate-500 max-w-xs truncate" title={leave.reason}>
                                    {leave.reason}
                                  </td>
                                  <td className="py-4.5 px-6">
                                    <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-bold ${
                                      leave.status === 'Approved' ? 'bg-emerald-50 text-emerald-700' :
                                      leave.status === 'Rejected' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'
                                    }`}>
                                      {leave.status}
                                    </span>
                                  </td>
                                  {currentUser.role !== 'employee' && (
                                    <td className="py-4.5 px-6 text-right space-x-2">
                                      {leave.status === 'Pending' ? (
                                        <div className="flex gap-1.5 justify-end">
                                          <button
                                            onClick={() => handleReviewLeave(leave.id, 'Approved')}
                                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm transition-all"
                                          >
                                            <Check className="h-3 w-3" /> Approve
                                          </button>
                                          <button
                                            onClick={() => handleReviewLeave(leave.id, 'Rejected')}
                                            className="px-2.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm transition-all"
                                          >
                                            <X className="h-3 w-3" /> Reject
                                          </button>
                                        </div>
                                      ) : (
                                        <span className="text-xs text-slate-400 italic">Resolved</span>
                                      )}
                                    </td>
                                  )}
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: DEPARTMENTS */}
              {activeTab === 'departments' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">Organizational Departments</h2>
                      <p className="text-xs text-slate-500">Corporate hierarchy, department heads and payroll structures</p>
                    </div>
                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => {
                          setDeptForm({ name: '', code: '', headName: '', color: 'indigo' });
                          setIsDeptModalOpen(true);
                        }}
                        className="flex items-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-indigo-600/15"
                      >
                        <Plus className="h-4 w-4" /> Add Department
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {departments.map((dept) => {
                      const deptEmployees = employees.filter(e => e.departmentId === dept.id);
                      const activeStaffCount = deptEmployees.filter(e => e.status === 'active').length;
                      
                      return (
                        <div key={dept.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between space-y-6">
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <span className="font-mono text-xs font-bold tracking-widest text-indigo-600 bg-indigo-50 px-2 py-1 rounded">
                                {dept.code}
                              </span>
                              <div className="h-3 w-3 rounded-full" style={{
                                backgroundColor: dept.color === 'indigo' ? '#4f46e5' :
                                                 dept.color === 'pink' ? '#db2777' :
                                                 dept.color === 'emerald' ? '#059669' :
                                                 dept.color === 'amber' ? '#d97706' : '#0d9488'
                              }} />
                            </div>

                            <div>
                              <h3 className="text-lg font-bold text-slate-900 leading-tight">{dept.name}</h3>
                              <p className="text-xs text-slate-400 mt-1">Manager: <span className="font-semibold text-slate-700">{dept.headName}</span></p>
                            </div>
                          </div>

                          <div className="border-t border-slate-50 pt-4 flex items-center justify-between text-xs text-slate-500">
                            <span>Active Enrollment</span>
                            <span className="font-bold text-slate-800">{activeStaffCount} Employees</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 6: HOLIDAYS */}
              {activeTab === 'holidays' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">National & Corporate Holidays</h2>
                      <p className="text-xs text-slate-500">Official vacation calendars and religious optional off days</p>
                    </div>
                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => setIsHolidayModalOpen(true)}
                        className="flex items-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-indigo-600/15"
                      >
                        <Plus className="h-4 w-4" /> Add Holiday Calendar Event
                      </button>
                    )}
                  </div>

                  <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                    <table className="w-full border-collapse text-left text-sm text-slate-600">
                      <thead className="bg-slate-50 text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100">
                        <tr>
                          <th className="py-4.5 px-6">Holiday Event Name</th>
                          <th className="py-4.5 px-6">Scheduled Date</th>
                          <th className="py-4.5 px-6">Classification</th>
                          <th className="py-4.5 px-6">Description Memo</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {holidays.map((h) => (
                          <tr key={h.id} className="hover:bg-slate-50/70 transition-all">
                            <td className="py-4.5 px-6 font-bold text-slate-900">{h.name}</td>
                            <td className="py-4.5 px-6 font-mono text-sm text-slate-700">{h.date}</td>
                            <td className="py-4.5 px-6">
                              <span className={`inline-flex px-2 py-0.5 rounded text-xs font-semibold ${
                                h.type === 'National' ? 'bg-indigo-50 text-indigo-700' :
                                h.type === 'Religious' ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'
                              }`}>
                                {h.type}
                              </span>
                            </td>
                            <td className="py-4.5 px-6 text-slate-500 italic max-w-sm truncate">{h.description}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 7: REPORTS & EXPORT CENTER */}
              {activeTab === 'reports' && (
                <div className="space-y-8">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900">Reports and Ledger Exports</h2>
                      <p className="text-xs text-slate-500">Aggregate working hours, late frequencies and exportable audits</p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => window.print()}
                        className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-semibold transition-all border border-slate-200"
                      >
                        <Printer className="h-4 w-4" /> Print Report
                      </button>
                      
                      <button
                        onClick={() => {
                          let csv = 'Employee ID,Name,Join Date,Email,Salary,Fingerprint ID\n';
                          employees.forEach(emp => {
                            csv += `"${emp.id}","${emp.name}","${emp.joinDate}","${emp.email}",${emp.salary},"${emp.fingerprintId || ''}"\n`;
                          });
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.setAttribute('href', url);
                          a.setAttribute('download', `ams_employees_report_${Date.now()}.csv`);
                          a.click();
                          showToast('CSV export downloaded successfully!');
                        }}
                        className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-indigo-600/10"
                      >
                        <Download className="h-4 w-4" /> Export CSV Ledger
                      </button>
                    </div>
                  </div>

                  {/* Summary Metric Ribbon */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-4">Total System Payroll</h3>
                      <div className="flex items-center gap-3">
                        <div className="bg-emerald-50 text-emerald-600 p-3 rounded-xl">
                          <DollarSign className="h-6 w-6" />
                        </div>
                        <div>
                          <span className="text-2xl font-extrabold text-slate-800">
                            ₹{employees.reduce((acc, curr) => acc + (curr.status === 'active' ? curr.salary : 0), 0).toLocaleString('en-IN')}
                          </span>
                          <span className="block text-xs text-slate-400">Total Monthly budget</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-4">Average Attendance Rate</h3>
                      <div className="flex items-center gap-3">
                        <div className="bg-indigo-50 text-indigo-600 p-3 rounded-xl">
                          <TrendingUp className="h-6 w-6" />
                        </div>
                        <div>
                          <span className="text-2xl font-extrabold text-slate-800">
                            {employees.length > 0 ? (94.2).toFixed(1) : 0}%
                          </span>
                          <span className="block text-xs text-slate-400">Based on past biometric records</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-4">Unexcused Absences</h3>
                      <div className="flex items-center gap-3">
                        <div className="bg-rose-50 text-rose-600 p-3 rounded-xl">
                          <AlertCircle className="h-6 w-6" />
                        </div>
                        <div>
                          <span className="text-2xl font-extrabold text-slate-800">2.4%</span>
                          <span className="block text-xs text-slate-400">Rate of absence per month</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* PDF Simulation layout */}
                  <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
                    <div className="border-b border-slate-100 pb-6">
                      <h3 className="text-lg font-bold text-slate-900 mb-1">Interactive Financial Compensation Index</h3>
                      <p className="text-xs text-slate-500">Audits mapping biometric working compliance and base structures</p>
                    </div>

                    <table className="w-full border-collapse text-left text-sm text-slate-600">
                      <thead className="bg-slate-50 text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100">
                        <tr>
                          <th className="py-3 px-4">Employee ID</th>
                          <th className="py-3 px-4">Staff Member</th>
                          <th className="py-3 px-4">Mapped Bio ID</th>
                          <th className="py-3 px-4">Base Monthly salary</th>
                          <th className="py-3 px-4">Working Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {employees.map((emp) => (
                          <tr key={emp.id} className="hover:bg-slate-50">
                            <td className="py-3.5 px-4 font-mono text-xs">{emp.id}</td>
                            <td className="py-3.5 px-4 font-bold text-slate-900">{emp.name}</td>
                            <td className="py-3.5 px-4 font-mono text-xs text-slate-500">{emp.fingerprintId}</td>
                            <td className="py-3.5 px-4 font-semibold">₹{emp.salary.toLocaleString('en-IN')}</td>
                            <td className="py-3.5 px-4">
                              <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                                emp.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                              }`}>
                                {emp.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 8: ARUVIXA AMS SCANNER SIMULATOR */}
              {activeTab === 'zktecho' && (
                <div className="space-y-8">
                  
                  {/* Explainer Intro */}
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">ARUVIXA AMS Biometric SDK Simulation</h2>
                    <p className="text-xs text-slate-500">
                      Replicates physical hardware machine signal packets. In the original Laravel project, fingerprint scanners send check-in requests directly. Use this panel to trigger mock device clock-ins.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* Left: Device Simulator Hardware graphic */}
                    <div className="bg-slate-900 text-slate-100 rounded-3xl p-6 shadow-2xl border border-indigo-500/10 flex flex-col justify-between space-y-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                          <span className="text-indigo-400 font-mono text-xs tracking-widest font-bold">ARUVIXA AMS Biometric Terminal</span>
                          <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full text-[10px] font-bold">
                            CONNECTED
                          </span>
                        </div>

                        {/* Interactive scanning animation / visual representation of reader */}
                        <div className="bg-slate-950 rounded-2xl p-8 flex flex-col items-center justify-center space-y-4 border border-slate-800 relative overflow-hidden">
                          <div className={`absolute top-0 left-0 right-0 h-1.5 bg-indigo-500 shadow-lg shadow-indigo-500/50 ${
                            isScanning ? 'animate-bounce' : 'opacity-0'
                          }`} />

                          <div className={`h-24 w-24 rounded-full flex items-center justify-center border-2 transition-all ${
                            isScanning ? 'border-indigo-500 bg-indigo-950/40 text-indigo-400 animate-pulse scale-105' : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-indigo-400 hover:border-indigo-500/30'
                          }`}>
                            <Fingerprint className="h-12 w-12" />
                          </div>

                          <div className="text-center">
                            <span className="text-sm font-bold text-slate-300 block">Biometric Sensor Reader</span>
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest">Place index finger flat</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 font-mono text-xs text-indigo-400 space-y-1">
                        <div>&gt;_ ARUVIXA AMS v11.23 logs...</div>
                        <div>&gt;_ Socket: TCP/IP Port 4370 IP: 192.168.1.201</div>
                        <div>&gt;_ Baud Rate: 115200 bps</div>
                        {isScanning && <div className="text-indigo-300 animate-pulse">&gt;_ Scanning biometric points... Validating User Fingerprint Matrix...</div>}
                        {scanResult && <div className={scanResult.success ? 'text-emerald-400' : 'text-rose-400'}>&gt;_ {scanResult.message}</div>}
                      </div>
                    </div>

                    {/* Right: Controller form */}
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 lg:col-span-2 space-y-6">
                      <h3 className="text-lg font-bold text-slate-900">Terminal Controller Settings</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                            Select Enrolled Employee
                          </label>
                          <select
                            value={scannedEmpId}
                            onChange={(e) => setScannedEmpId(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none text-slate-700"
                          >
                            {employees.map(e => (
                              <option key={e.id} value={e.id}>{e.name} (Mapped Fingerprint: {e.fingerprintId})</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                            Signal Action
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setScannerAction('checkIn')}
                              className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                                scannerAction === 'checkIn' ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'border-slate-200 bg-slate-50 text-slate-600'
                              }`}
                            >
                              Check-In Punch
                            </button>
                            <button
                              type="button"
                              onClick={() => setScannerAction('checkOut')}
                              className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                                scannerAction === 'checkOut' ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'border-slate-200 bg-slate-50 text-slate-600'
                              }`}
                            >
                              Check-Out Punch
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                            Simulated Time (HH:MM)
                          </label>
                          <input
                            type="time"
                            value={scannerTime}
                            onChange={(e) => setScannerTime(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm outline-none text-slate-700"
                          />
                          <p className="text-[10px] text-slate-400 mt-1">
                            Useful to trigger 'Late' flags (after shift start time + 15 min grace).
                          </p>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-slate-100">
                        <button
                          type="button"
                          disabled={isScanning}
                          onClick={simulateFingerprintScan}
                          className="w-full py-4 bg-slate-900 text-white rounded-xl font-semibold text-sm hover:bg-slate-800 shadow-lg disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          <Fingerprint className="h-5 w-5" />
                          {isScanning ? 'Transmitting Scan Packets...' : 'Transmit ZKTecho Biometric Fingerprint Log'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      )}

      {/* --- MODAL 1: ADD / EDIT EMPLOYEE --- */}
      {isEmployeeModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 md:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsEmployeeModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-xl font-bold text-slate-900 mb-2">
              {editingEmployee ? 'Modify Staff Record' : 'Enroll New Employee ID'}
            </h3>
            <p className="text-xs text-slate-500 mb-6">Enrolling creates a system profile and associates a fingerprint code.</p>

            <form onSubmit={handleSaveEmployee} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={empForm.name}
                    onChange={(e) => setEmpForm({ ...empForm, name: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                    placeholder="E.g. Zaryab Khan"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={empForm.email}
                    onChange={(e) => setEmpForm({ ...empForm, email: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                    placeholder="username@ams.com"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Phone Contact *</label>
                  <input
                    type="tel"
                    required
                    value={empForm.phone}
                    onChange={(e) => setEmpForm({ ...empForm, phone: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                    placeholder="+93 788 123456"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Department</label>
                  <select
                    value={empForm.departmentId}
                    onChange={(e) => setEmpForm({ ...empForm, departmentId: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Designation Role *</label>
                  <input
                    type="text"
                    required
                    value={empForm.designation}
                    onChange={(e) => setEmpForm({ ...empForm, designation: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                    placeholder="E.g. UI Designer"
                  />
                </div>

                <div>
                   <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Monthly Salary (INR)</label>
                   <input
                     type="number"
                     value={empForm.salary}
                     onChange={(e) => setEmpForm({ ...empForm, salary: Number(e.target.value) })}
                     className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                   />
                 </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Biometric Fingerprint ID</label>
                  <input
                    type="text"
                    value={empForm.fingerprintId}
                    onChange={(e) => setEmpForm({ ...empForm, fingerprintId: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-mono outline-none"
                    placeholder="E.g. FP-105"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Gender</label>
                  <select
                    value={empForm.gender}
                    onChange={(e) => setEmpForm({ ...empForm, gender: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Current Status</label>
                  <select
                    value={empForm.status}
                    onChange={(e) => setEmpForm({ ...empForm, status: e.target.value as 'active' | 'inactive' })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                  >
                    <option value="active">Active Service</option>
                    <option value="inactive">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 flex gap-3 justify-end border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEmployeeModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-all shadow-md shadow-indigo-600/10"
                >
                  Commit Staff Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 2: MANUAL ATTENDANCE SIGN IN / OVERRIDE --- */}
      {isAttendanceModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setIsAttendanceModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-xl font-bold text-slate-900 mb-2">
              {editingAttendance ? 'Adjust Biometric Log' : 'Create Manual Punch'}
            </h3>
            <p className="text-xs text-slate-500 mb-6">Manually forces check-in metrics on behalf of staff logs.</p>

            <form onSubmit={handleSaveAttendance} className="space-y-4">
              {!editingAttendance && (
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Employee Account</label>
                  <select
                    value={attForm.employeeId}
                    onChange={(e) => setAttForm({ ...attForm, employeeId: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                  >
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Check-In Log Date</label>
                <input
                  type="date"
                  required
                  value={attForm.date}
                  onChange={(e) => setAttForm({ ...attForm, date: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Check In Time</label>
                  <input
                    type="time"
                    value={attForm.checkIn}
                    onChange={(e) => setAttForm({ ...attForm, checkIn: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Check Out Time</label>
                  <input
                    type="time"
                    value={attForm.checkOut}
                    onChange={(e) => setAttForm({ ...attForm, checkOut: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Attendance Status Override</label>
                <select
                  value={attForm.status}
                  onChange={(e) => setAttForm({ ...attForm, status: e.target.value as AttendanceRecord['status'] })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                >
                  <option value="Present">Present (On Time)</option>
                  <option value="Late">Late Arrival</option>
                  <option value="Half Day">Half Day Sign Off</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Absent">Absent</option>
                </select>
              </div>

              <div className="pt-4 flex gap-3 justify-end border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAttendanceModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-all shadow-md shadow-indigo-600/10"
                >
                  Save Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 3: SUBMIT LEAVE APPLICATION --- */}
      {isLeaveModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setIsLeaveModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-xl font-bold text-slate-900 mb-2">Request Leave Absence</h3>
            <p className="text-xs text-slate-500 mb-6">Subject to reviewing and formal approval from Priya Sharma / HR.</p>

            <form onSubmit={handleApplyLeave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Leave Classification</label>
                <select
                  value={leaveForm.leaveType}
                  onChange={(e) => setLeaveForm({ ...leaveForm, leaveType: e.target.value as LeaveRequest['leaveType'] })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                >
                  <option value="Annual">Annual Paid Leave</option>
                  <option value="Sick">Sick Certificate Leave</option>
                  <option value="Casual">Casual Off-day Leave</option>
                  <option value="Unpaid">Unpaid Personal Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={leaveForm.startDate}
                    onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={leaveForm.endDate}
                    onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Reason & Memo *</label>
                <textarea
                  required
                  rows={3}
                  value={leaveForm.reason}
                  onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none resize-none placeholder:text-slate-400"
                  placeholder="Detail the urgent tasks reason for absence..."
                />
              </div>

              <div className="pt-4 flex gap-3 justify-end border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsLeaveModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-all shadow-md shadow-indigo-600/10"
                >
                  File Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 4: ADD DEPARTMENT --- */}
      {isDeptModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setIsDeptModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-xl font-bold text-slate-900 mb-2">Create New Department</h3>
            <p className="text-xs text-slate-500 mb-6 font-semibold">Organize staff members into separate command teams.</p>

            <form onSubmit={handleSaveDepartment} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Department Name *</label>
                <input
                  type="text"
                  required
                  value={deptForm.name}
                  onChange={(e) => setDeptForm({ ...deptForm, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  placeholder="E.g. Quality Assurance"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Code/Abbreviation *</label>
                  <input
                    type="text"
                    required
                    value={deptForm.code}
                    onChange={(e) => setDeptForm({ ...deptForm, code: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none uppercase"
                    placeholder="E.g. QA"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">H.O.D. Manager</label>
                  <input
                    type="text"
                    value={deptForm.headName}
                    onChange={(e) => setDeptForm({ ...deptForm, headName: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                    placeholder="E.g. Ali Ahmed"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Theme Identifier Color</label>
                <select
                  value={deptForm.color}
                  onChange={(e) => setDeptForm({ ...deptForm, color: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                >
                  <option value="indigo">Indigo Purple</option>
                  <option value="pink">Hot Pink</option>
                  <option value="emerald">Emerald Green</option>
                  <option value="amber">Warm Amber</option>
                  <option value="teal">Deep Teal</option>
                </select>
              </div>

              <div className="pt-4 flex gap-3 justify-end border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsDeptModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-all"
                >
                  Confirm Creation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 5: ADD HOLIDAY --- */}
      {isHolidayModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setIsHolidayModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all"
            >
              <X className="h-5 w-5" />
            </button>

            <h3 className="text-xl font-bold text-slate-900 mb-2">Declare Official Holiday</h3>
            <p className="text-xs text-slate-500 mb-6 font-semibold">Declaring holidays will exempt presence requirements for this date.</p>

            <form onSubmit={handleSaveHoliday} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Holiday Name *</label>
                <input
                  type="text"
                  required
                  value={holidayForm.name}
                  onChange={(e) => setHolidayForm({ ...holidayForm, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  placeholder="E.g. Pakistan Day"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Schedule Date *</label>
                  <input
                    type="date"
                    required
                    value={holidayForm.date}
                    onChange={(e) => setHolidayForm({ ...holidayForm, date: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Holiday Type</label>
                  <select
                    value={holidayForm.type}
                    onChange={(e) => setHolidayForm({ ...holidayForm, type: e.target.value as Holiday['type'] })}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none text-slate-700"
                  >
                    <option value="National">National Day Off</option>
                    <option value="Religious">Religious Occasion</option>
                    <option value="Optional">Optional Holiday</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">Memo description</label>
                <input
                  type="text"
                  value={holidayForm.description}
                  onChange={(e) => setHolidayForm({ ...holidayForm, description: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none"
                  placeholder="E.g. Celebration of annual events..."
                />
              </div>

              <div className="pt-4 flex gap-3 justify-end border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsHolidayModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-all"
                >
                  Declare Holiday
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
